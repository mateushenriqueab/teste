import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import url from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

app.get('/mfe.umd.js', (req, res) => {
  const bundle = path.resolve(__dirname, '../mfe-standalone-umd/dist/mfe.umd.js');
  if (!fs.existsSync(bundle)) return res.status(404).send('bundle not built yet');
  res.type('application/javascript').send(fs.readFileSync(bundle, 'utf-8'));
});

app.get('/entity/:ref', (req, res) => {
  const ref = decodeURIComponent(req.params.ref);
  res.json({
    entityRef: ref,
    matched: true,
    source: 'mock-db',
    now: new Date().toISOString(),
    notes: 'Substitua por lookup real no seu banco.'
  });
});

app.listen(PORT, () => {
  console.log(`Mini backend listening on http://localhost:${PORT}`);
});
