export type Bridge = {
  version: string;
  theme?: any;
  locale?: string;
  user?: {
    ref?: string;
    profile?: any;
    getIdToken?: () => Promise<string | undefined>;
    getUserId?: () => string | undefined;
  };
  navigate?: (to: string) => void;
  ui?: {
    notify?: (message: string, severity?: 'info'|'warning'|'error'|'success') => void;
    reportError?: (e: any, context?: string) => void;
  };
  apis?: {
    catalog?: { getEntities?: (query?: any) => Promise<any> };
    config?: { getOptionalString?: (key: string) => string | undefined };
    discovery?: { getBaseUrl?: (svc: string) => Promise<string> };
    fetch?: { request?: (url: string, init?: RequestInit) => Promise<Response> };
    permissions?: { authorize?: (req: any) => Promise<any> };
    storage?: { get?: (k: string) => any; set?: (k: string, v: any) => void; remove?: (k: string) => void };
    analytics?: { capture?: (e: any) => void };
    featureFlags?: { isActive?: (flag: string) => boolean };
  };
};
