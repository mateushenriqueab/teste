import React from 'react';
import { createRoot } from 'react-dom/client';
import RemoteApp from './RemoteApp';
import type { Bridge } from './types';

const bridge: Bridge = {
  version: '2.1',
  ui: { notify: (m,s) => console.log(s || 'info', m), reportError: e => console.error(e) },
  navigate: (to: string) => console.log('navigate ->', to),
};

createRoot(document.getElementById('root')!).render(<RemoteApp bridge={bridge} backendUrl="http://localhost:4000" />);
