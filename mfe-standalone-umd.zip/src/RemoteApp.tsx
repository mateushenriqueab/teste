import React from 'react';
import CssBaseline from '@mui/material/CssBaseline';

import {
  Box,
  Card,
  CardHeader,
  CardContent,
  Button,
  TextField,
  Grid,
  Chip,
  Typography,
} from '@mui/material';

import { useTheme,ThemeProvider,createTheme } from '@material-ui/core/styles';



type Bridge = {
  theme?: any;
  navigate?: (to: string) => void;
  ui?: { notify?: (m: string, s?: 'info'|'warning'|'error'|'success') => void; reportError?: (e: any, c?: string) => void };
  apis?: {
    catalog?: {
      getEntities?: (query?: any) => Promise<{ items: any[] }>;
    };
  };
};

type Props = { bridge: Bridge; backendUrl?: string };

const RemoteApp: React.FC<Props> = ({ bridge, backendUrl = 'http://localhost:4000' }) => {
  const theme = React.useMemo(() => (bridge.theme ? bridge.theme : createTheme()), [bridge.theme]);

  const [entityRef, setEntityRef] = React.useState('component:default/example-website');
  const [data, setData] = React.useState<any>(null);

  // NOVO: apps do catálogo (Component com spec.type = "app")
  const [apps, setApps] = React.useState<any[]>([]);
  const [loadingApps, setLoadingApps] = React.useState(false);

  const fetchEntity = async () => {
    try {
      const r = await fetch(`${backendUrl}/entity/${encodeURIComponent(entityRef)}`);
      const j = await r.json();
      setData(j);
      bridge.ui?.notify?.('Carregado com sucesso', 'success');
    } catch (e) {
      bridge.ui?.reportError?.(e, 'fetchEntity');
      bridge.ui?.notify?.('Falha ao buscar dados', 'error');
    }
  };

  const fetchApps = async () => {
    if (!bridge?.apis?.catalog?.getEntities) {
      bridge.ui?.notify?.('Catalog API indisponível no bridge', 'warning');
      return;
    }
    setLoadingApps(true);
    try {
      const res = await bridge.apis.catalog.getEntities({
        // filtro pelo tipo
        filter: { kind: ['Component'] },
        // reduz payload (opcional)
        fields: ['kind', 'metadata', 'spec', 'relations'],
        limit: 50,
      });
      setApps(res?.items ?? []);
      bridge.ui?.notify?.(`Carregado ${res?.items?.length ?? 0} app(s)`, 'success');
    } catch (e) {
      bridge.ui?.reportError?.(e, 'fetchApps');
      bridge.ui?.notify?.('Falha ao buscar apps', 'error');
    } finally {
      setLoadingApps(false);
    }
  };

  React.useEffect(() => {
    // carrega automaticamente na montagem; se preferir manual, remova
    fetchApps();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
      <ThemeProvider theme={theme}>
        <CssBaseline />

        <Box display="grid" gap={2}>
    


          {/* NOVO: Lista de apps do catálogo */}
          <Card>
            <CardHeader
              title="Apps do catálogo"
              subheader="Listando Components com spec.type = 'app'"
              action={
                <Button onClick={fetchApps} disabled={loadingApps} variant="outlined">
                  {loadingApps ? 'Carregando...' : 'Recarregar'}
                </Button>
              }
            />
            <CardContent>
              {apps.length === 0 ? (
                <Typography variant="body2" color="text.secondary">
                  {loadingApps ? 'Carregando…' : 'Nenhum app encontrado.'}
                </Typography>
              ) : (
                <Grid container spacing={2}>
                  {apps.map((it, idx) => {
                    const name = it?.metadata?.name ?? 'sem-nome';
                    const ns = it?.metadata?.namespace ?? 'default';
                    const lifecycle = it?.spec?.lifecycle ?? 'unknown';
                    const owner =
                      it?.spec?.owner ??
                      it?.relations?.find((r: any) => r.type === 'ownedBy')?.targetRef ??
                      'unknown';
                    const system =
                      it?.spec?.system ??
                      it?.relations?.find((r: any) => r.type === 'partOf')?.targetRef ??
                      '—';

                    return (
                        <Grid size={{ xs: 4 }} key={`${name}-${idx}`}>
                        <Card variant="outlined">
                          <CardHeader
                            title={name}
                            subheader={`namespace: ${ns}`}
                          />
                          <CardContent>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                              <Chip label={`type: app`} size="small" />
                              <Chip label={`lifecycle: ${lifecycle}`} size="small" />
                              <Chip label={`owner: ${owner}`} size="small" />
                              {system && <Chip label={`system: ${system}`} size="small" />}
                            </Box>
                          </CardContent>
                        </Card>
                      </Grid>
                    );
                  })}
                </Grid>
              )}
            </CardContent>
          </Card>
        </Box>
      </ThemeProvider>
  );
};

export default RemoteApp;
