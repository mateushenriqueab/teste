import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import RemoteApp from './RemoteApp';
import type { Bridge } from './types';

let root: Root | null = null;

export function mount(el: HTMLElement, props: { bridge: Bridge, backendUrl?: string }) {
  if (!el) throw new Error('container inválido');
  if (!root) root = createRoot(el);
  root.render(<RemoteApp {...props} />);
}

export function unmount() {
  root?.unmount();
  root = null;
}

(window as any).DevkitMFE = { mount, unmount };
