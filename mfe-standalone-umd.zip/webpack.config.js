const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const isLibBuild = process.env.LIB_BUILD === '1';

module.exports = {
  entry: isLibBuild ? './src/mount.tsx' : './src/standalone.tsx',
  output: isLibBuild
    ? {
        filename: 'mfe.umd.js',
        path: path.resolve(__dirname, 'dist'),
        publicPath: 'auto',
        clean: true,
        library: { name: 'DevkitMFE', type: 'umd' },
      }
    : {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
        publicPath: '/',
        clean: true,
      },
  resolve: { extensions: ['.tsx', '.ts', '.js'] },
  module: {
    rules: [
      { test: /\.tsx?$/, use: 'ts-loader', exclude: /node_modules/ },
      { test: /\.css$/i, use: ['style-loader', 'css-loader'] }
    ],
  },
  devServer: {
    static: path.join(__dirname, 'dist'),
    port: 3009,
    hot: true,
    historyApiFallback: true,
    headers: { 'Access-Control-Allow-Origin': '*' },
  },
  plugins: isLibBuild ? [] : [ new HtmlWebpackPlugin({ template: './public/index.html' }) ],
};
