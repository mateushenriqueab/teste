import React from 'react';
import { Page, Header, Content } from '@backstage/core-components';
import {
  useApi,
  configApiRef,
  identityApiRef,
  alertApiRef,
  errorApiRef,
  discoveryApiRef,
  fetchApiRef,
  storageApiRef,
  analyticsApiRef,
  featureFlagsApiRef,
} from '@backstage/core-plugin-api';
import { permissionApiRef, PermissionApi } from '@backstage/plugin-permission-react';
import { catalogApiRef } from '@backstage/plugin-catalog-react';
import { useTheme } from '@material-ui/core/styles';
import { useNavigate } from 'react-router-dom';
import { RemoteUmd } from './RemoteUmd';


export const PluginMfeChassiPage = () => {
  const catalogApi = useApi(catalogApiRef);
  const configApi = useApi(configApiRef);
  const identityApi = useApi(identityApiRef);
  const alertApi = useApi(alertApiRef);
  const errorApi = useApi(errorApiRef);
  const discoveryApi = useApi(discoveryApiRef);
  const fetchApi = useApi(fetchApiRef);
  const permissionApi = useApi<PermissionApi>(permissionApiRef);
  const storageApi = useApi(storageApiRef);
  const analyticsApi = useApi(analyticsApiRef);
  const flagsApi = useApi(featureFlagsApiRef);
  const theme = useTheme();
  const navigate = useNavigate();

  const remoteUrl =
    configApi.getOptionalString('mfeChassi.umdUrl') ??
    'http://localhost:4000/mfe.umd.js';
  const versionKey =
    configApi.getOptionalString('mfeChassi.version') ?? undefined;

  const themeOptions = React.useMemo(
    () => ({
      palette: theme.palette,
      typography: theme.typography,
      shape: theme.shape,
      overrides: (theme as any).overrides,
      props: (theme as any).props,
      zIndex: (theme as any).zIndex,
    }),
    [theme],
  );

  const bridge = React.useMemo(
    () => ({
      version: '2.1',
      theme: themeOptions,
      locale: navigator.language || 'pt-BR',
      user: {
        ref: (identityApi as any).getUserEntityRef?.(),
        profile:
          (identityApi as any).getProfileInfo?.() ??
          (identityApi as any).getBackstageIdentity?.(),
        getIdToken: async () => {
          const creds = await identityApi.getCredentials?.();
          return creds?.token;
        },
        getUserId: async () => {
          const bi = await (identityApi as any).getBackstageIdentity?.();
          return bi?.userEntityRef;
        },
      },
      navigate: (to: string) => navigate(to),
      ui: {
        notify: (
          message: string,
          severity: 'info' | 'warning' | 'error' | 'success' = 'info',
        ) => alertApi.post({ message, severity }),
        reportError: (e: unknown, context?: string) => {
          const err = e instanceof Error ? e : new Error(String(e));
          if (context) err.message = `[${context}] ${err.message}`;
          errorApi.post(err, { hidden: false });
        },
      },
      apis: {
        catalog: { getEntities: (query: any) => catalogApi.getEntities(query) },
        config: {
          getOptionalString: (key: string) => configApi.getOptionalString(key),
        },
        discovery: {
          getBaseUrl: (svc: string) => discoveryApi.getBaseUrl(svc),
        },
        fetch: {
          request: (url: string, init?: RequestInit) => fetchApi.fetch(url, init),
        },
        permissions: {
          // Wrapper compatível com ambas assinaturas (antiga e nova)
          authorize: async (req: any) => {
            try {
              const anyApi = permissionApi as any;
              if (typeof anyApi?.authorize !== 'function') {
                return { decision: 'DENY' as const };
              }

              // checa aridade da função: algumas versões recebem (req), outras ([req])
              const wantsSingle = anyApi.authorize.length === 1;

              const result = wantsSingle
                ? await anyApi.authorize(req)     // assinatura antiga: (req)
                : await anyApi.authorize([req]); // assinatura nova: ([req])

              // normaliza resposta para sempre devolver o primeiro item quando for array
              return Array.isArray(result) ? result[0] : result;
            } catch (e) {
              console.warn('Falha ao autorizar permissão:', e);
              return { decision: 'DENY' as const };
            }
          },
        },
storage: {
  get: async (k: string) => {
    const bucket = storageApi.forBucket('mfe-standalone');
    const snapshot = await bucket.snapshot(k);
    return snapshot?.value;
  },
  set: async (k: string, v: any) => {
    const bucket = storageApi.forBucket('mfe-standalone');
    await bucket.set(k, v);
  },
  remove: async (k: string) => {
    const bucket = storageApi.forBucket('mfe-standalone');
    await bucket.remove(k);
  },
},
        analytics: { capture: (e: any) => analyticsApi.captureEvent?.(e) },
        featureFlags: { isActive: (flag: string) => flagsApi.isActive(flag) },
      },
    }),
    [
      themeOptions,
      navigate,
      identityApi,
      alertApi,
      errorApi,
      catalogApi,
      configApi,
      discoveryApi,
      fetchApi,
      permissionApi,
      storageApi,
      analyticsApi,
      flagsApi,
    ],
  );

  return (
    <Page themeId="tool">
      <Header
        title="Canais digitais"
        subtitle="MFE remoto, sem backend no Backstage"
      />
      <Content>
        <RemoteUmd
          remoteUrl={remoteUrl}
          versionKey={versionKey}
          props={{ bridge }}
        />
      </Content>
    </Page>
  );
};
