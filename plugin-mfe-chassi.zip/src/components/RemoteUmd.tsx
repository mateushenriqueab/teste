import React from 'react';

declare global {
  interface Window {
    DevkitMFE?: { mount: (el: HTMLElement, props?: any) => void; unmount?: () => void };
  }
}

async function injectScript(src: string, id: string) {
  await new Promise<void>((resolve, reject) => {
    const ex = document.getElementById(id) as HTMLScriptElement | null;
    if (ex) return resolve();
    const s = document.createElement('script');
    s.id = id;
    s.src = src;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error(`Falha ao carregar ${src}`));
    document.head.appendChild(s);
  });
}

type Props = { remoteUrl: string; props?: any; versionKey?: string };
export const RemoteUmd: React.FC<Props> = ({ remoteUrl, props, versionKey }) => {
  const ref = React.useRef<HTMLDivElement>(null);
  const [error, setError] = React.useState<string | null>(null);
  const url = React.useMemo(() => versionKey ? `${remoteUrl}?v=${encodeURIComponent(versionKey)}` : remoteUrl, [remoteUrl, versionKey]);
  const id = React.useMemo(() => `mfe-${btoa(url).replace(/=/g,'')}`, [url]);

  React.useEffect(() => {
    let mounted = true;
    injectScript(url, id)
      .then(() => {
        if (!mounted) return;
        if (!window.DevkitMFE?.mount) throw new Error('DevkitMFE.mount não encontrado');
        if (ref.current) window.DevkitMFE.mount(ref.current, props);
      })
      .catch(e => setError(String(e)));
    return () => { mounted = false; window.DevkitMFE?.unmount?.(); };
  }, [url, id, props]);

  if (error) return <div>Falha ao carregar MFE: {error}</div>;
  return <div ref={ref} />;
};
