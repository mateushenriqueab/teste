import { createRouteRef } from '@backstage/core-plugin-api';
export const pluginMfeChassiRouteRef = createRouteRef({
  id: 'plugin-mfe-chassi-route',
  title: 'Canais digitais',
});
