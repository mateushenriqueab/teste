import { createPlugin, createRoutableExtension } from '@backstage/core-plugin-api';
import { pluginMfeChassiRouteRef } from './routes';

export const pluginMfeChassiPlugin = createPlugin({
  id: 'plugin-mfe-chassi',
  routes: { root: pluginMfeChassiRouteRef },
});

export const PluginMfeChassiPage = pluginMfeChassiPlugin.provide(
  createRoutableExtension({
    name: 'PluginMfeChassiPage',
    component: () => import('./components/PluginMfeChassiPage').then(m => m.PluginMfeChassiPage),
    mountPoint: pluginMfeChassiRouteRef,
  }),
);
